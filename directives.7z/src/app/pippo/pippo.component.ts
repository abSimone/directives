import { Component } from '@angular/core';

@Component({
  selector: 'app-pippo',
  templateUrl: './pippo.component.html',
  styleUrls: ['./pippo.component.css']
})
export class PippoComponent {

}
